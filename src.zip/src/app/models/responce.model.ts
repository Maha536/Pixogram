export class ResponseData{
    message : String;
    timestamp : number;
    profile : String;
    firstname : string;
    lastname : string;
    id : number;
    // additional info
}
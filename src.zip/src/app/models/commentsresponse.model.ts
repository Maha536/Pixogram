export class CommentsResponse{
    userName : String;
	comments : String;
	createdOn : String;
}
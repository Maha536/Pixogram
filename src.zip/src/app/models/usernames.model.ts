export class Usernames{
    usernames : Array<String>;
}
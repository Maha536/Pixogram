export class Comments{
     id : number;
	 mediaId : number;
	 userId : number;
	 comments : string;
	 createdOn : Date;
}
export class SearchedUser {
	userId : number;
	name : string;
	profileUrl : string;
	followed : boolean;
}
export class Userid{
    id : number;
    firstname : String;
    lastname : String;
}
export class FollowUserData{
    userId : number;
	username : string;
    name : string;
	url : string;
}
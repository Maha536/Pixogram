import { FollowUserData } from "./followuserdata.model";

export class FollowUserDataList{
    followList : Array<FollowUserData>;
}